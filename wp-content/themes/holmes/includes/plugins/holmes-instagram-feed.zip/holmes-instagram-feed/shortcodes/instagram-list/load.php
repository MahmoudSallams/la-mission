<?php

include_once HOLMES_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/functions.php';
include_once HOLMES_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/instagram-list.php';