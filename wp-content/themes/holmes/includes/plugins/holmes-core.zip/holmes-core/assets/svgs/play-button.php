<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
        viewBox="0 0 37 44" style="enable-background:new 0 0 37 44;" xml:space="preserve">
<style type="text/css">
    .mkdf-st0 {
        fill: #020202;
    }
</style>
    <polygon class="mkdf-st0" points="1,1 1,43 36,22 "/>
</svg>