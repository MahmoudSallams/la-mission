<?php

include_once HOLMES_CORE_SHORTCODES_PATH . '/colored-clients/functions.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/colored-clients/colored-clients.php';