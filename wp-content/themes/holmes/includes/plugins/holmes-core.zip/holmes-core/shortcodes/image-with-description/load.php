<?php

include_once HOLMES_CORE_SHORTCODES_PATH . '/image-with-description/functions.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/image-with-description/image-with-description.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/image-with-description/image-with-description-item.php';