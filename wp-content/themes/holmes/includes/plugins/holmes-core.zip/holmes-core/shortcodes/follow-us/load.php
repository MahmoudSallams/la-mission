<?php

include_once HOLMES_CORE_SHORTCODES_PATH . '/follow-us/functions.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/follow-us/follow-us.php';