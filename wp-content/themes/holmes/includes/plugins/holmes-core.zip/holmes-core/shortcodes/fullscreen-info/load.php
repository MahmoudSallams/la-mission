<?php

include_once HOLMES_CORE_SHORTCODES_PATH . '/fullscreen-info/functions.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/fullscreen-info/fullscreen-info.php';