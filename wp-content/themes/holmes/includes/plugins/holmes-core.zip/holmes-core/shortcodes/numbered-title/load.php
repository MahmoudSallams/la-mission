<?php

include_once HOLMES_CORE_SHORTCODES_PATH . '/numbered-title/functions.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/numbered-title/numbered-title.php';