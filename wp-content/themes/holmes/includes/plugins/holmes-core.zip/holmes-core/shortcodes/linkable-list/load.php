<?php

include_once HOLMES_CORE_SHORTCODES_PATH . '/linkable-list/functions.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/linkable-list/linkable-list.php';