<?php

include_once HOLMES_CORE_SHORTCODES_PATH . '/image-with-list/functions.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/image-with-list/image-with-list.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/image-with-list/image-with-list-item.php';