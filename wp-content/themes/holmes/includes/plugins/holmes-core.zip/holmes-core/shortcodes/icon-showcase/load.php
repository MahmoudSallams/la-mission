<?php

include_once HOLMES_CORE_SHORTCODES_PATH . '/icon-showcase/functions.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/icon-showcase/icon-showcase.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/icon-showcase/icon-showcase-item.php';