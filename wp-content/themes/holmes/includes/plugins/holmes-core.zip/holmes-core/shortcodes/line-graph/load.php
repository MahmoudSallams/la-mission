<?php

include_once HOLMES_CORE_SHORTCODES_PATH . '/line-graph/functions.php';
include_once HOLMES_CORE_SHORTCODES_PATH . '/line-graph/line-graph.php';