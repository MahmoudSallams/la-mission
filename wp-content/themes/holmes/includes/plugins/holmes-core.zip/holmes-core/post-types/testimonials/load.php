<?php

include_once HOLMES_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once HOLMES_CORE_CPT_PATH . '/testimonials/helper-functions.php';