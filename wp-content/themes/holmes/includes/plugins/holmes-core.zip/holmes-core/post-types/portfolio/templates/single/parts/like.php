<div class="mkdf-portfolio-like">
    <?php if( function_exists('holmes_mkdf_get_like') ) holmes_mkdf_get_like(); ?>
</div>
