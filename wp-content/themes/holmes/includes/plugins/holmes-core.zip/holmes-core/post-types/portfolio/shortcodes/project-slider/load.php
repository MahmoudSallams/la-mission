<?php

require_once 'project-slider.php';
require_once 'helper-functions.php';