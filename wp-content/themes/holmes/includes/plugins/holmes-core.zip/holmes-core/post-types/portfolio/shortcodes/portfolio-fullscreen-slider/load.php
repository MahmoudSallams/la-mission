<?php

require_once 'portfolio-fullscreen-slider.php';
require_once 'helper-functions.php';