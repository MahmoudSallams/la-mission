<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/social-icon/functions.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/social-icon/social-icon.php';