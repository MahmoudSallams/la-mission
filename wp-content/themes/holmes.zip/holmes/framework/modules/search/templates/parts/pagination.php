<?php

holmes_mkdf_get_module_template_part( 'templates/parts/pagination/standard', 'blog', '', $params );