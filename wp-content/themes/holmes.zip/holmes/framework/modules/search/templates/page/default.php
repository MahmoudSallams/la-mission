<?php holmes_mkdf_get_module_template_part( 'templates/parts/search-form', 'search', '', $params ); ?>
<?php holmes_mkdf_get_module_template_part( 'templates/parts/loop', 'search', '', $params ); ?>
<?php holmes_mkdf_get_module_template_part( 'templates/parts/pagination', 'search', '', $params ); ?>