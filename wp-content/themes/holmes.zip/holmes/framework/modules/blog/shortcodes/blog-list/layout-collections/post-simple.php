<li class="mkdf-bl-item mkdf-item-space clearfix">
    <div class="mkdf-bli-inner">
		<?php holmes_mkdf_get_module_template_part( 'templates/parts/media', 'blog', '', $params ); ?>
        <div class="mkdf-bli-content">
			<?php holmes_mkdf_get_module_template_part( 'templates/parts/title', 'blog', '', $params ); ?>
			<?php holmes_mkdf_get_module_template_part( 'templates/parts/post-info/date', 'blog', 'shortcode', $params ); ?>
        </div>
    </div>
</li>