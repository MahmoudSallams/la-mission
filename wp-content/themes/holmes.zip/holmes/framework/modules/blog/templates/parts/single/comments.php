<?php
if(holmes_mkdf_show_comments()){
    comments_template('', true);
}