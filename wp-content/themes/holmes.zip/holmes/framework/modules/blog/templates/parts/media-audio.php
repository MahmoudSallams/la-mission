<span class="mkdf-post-single-media">
<?php

holmes_mkdf_get_module_template_part( 'templates/parts/image', 'blog', '', $params );
holmes_mkdf_get_module_template_part( 'templates/parts/post-type/audio', 'blog', '', $params );

?>
</span>
