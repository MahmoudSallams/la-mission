<div class="mkdf-post-info-category">
    <span><?php esc_html_e( 'in', 'holmes' ); ?></span>
	<?php the_category( ', ' ); ?>
</div>