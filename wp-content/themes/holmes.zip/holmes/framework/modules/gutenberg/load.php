<?php
if ( holmes_mkdf_is_gutenberg_plugin_installed() || holmes_mkdf_is_wp_gutenberg_installed() ) {
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/gutenberg/functions.php';
}
