<div class="mkdf-gutenb-title-holder">
    <div class="mkdf-gutenb-title-wrapper">
        <div class="mkdf-gutenb-title-inner">
            <div class="mkdf-grid">
				<?php if ( ! empty( $title ) ) : ?>
					<?php echo '<' . esc_attr( $title_tag ); ?> class="mkdf-page-title entry-title">
					<?php echo esc_html( $title ); ?>
					<?php echo '</' . esc_attr( $title_tag ); ?>>
				<?php endif; ?>
            </div>
        </div>
    </div>
</div>