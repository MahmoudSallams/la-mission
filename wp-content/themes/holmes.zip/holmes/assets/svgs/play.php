<svg version="1.1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px"
        viewBox="0 0 82 82" style="enable-background:new 0 0 82 82;" xml:space="preserve">
    <g>
        <circle cx="41" cy="40.8" r="40"/>
    </g>
    <polygon points="53,41.3 33,29.3 33,52.3 "/>
</svg>
