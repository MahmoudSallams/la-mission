<?php do_action( 'holmes_mkdf_portfolio_page_navigation' ); ?>
<?php do_action( 'holmes_mkdf_get_footer_template' );